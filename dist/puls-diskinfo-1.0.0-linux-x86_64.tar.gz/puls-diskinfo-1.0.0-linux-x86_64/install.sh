#!/bin/bash
#
# PULS DiskInfo Installer
#
set -euo pipefail

PREFIX="${PREFIX:-/usr/local}"

echo "Installing PULS DiskInfo to $PREFIX..."

# Check for root
if [ "$(id -u)" -ne 0 ]; then
    echo "Error: This script must be run as root (use sudo)."
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Install binary
install -Dm755 "$SCRIPT_DIR/puls-diskinfo" "$PREFIX/bin/puls-diskinfo"

# Install helper
install -Dm755 "$SCRIPT_DIR/puls-diskinfo-helper" "$PREFIX/libexec/puls-diskinfo-helper"

# Install desktop file
install -Dm644 "$SCRIPT_DIR/data/io.github.puls.diskinfo.desktop" \
    "$PREFIX/share/applications/io.github.puls.diskinfo.desktop"

# Install polkit policy
install -Dm644 "$SCRIPT_DIR/data/io.github.puls.diskinfo.policy" \
    "$PREFIX/share/polkit-1/actions/io.github.puls.diskinfo.policy"

# Update polkit policy helper path
sed -i "s|/usr/libexec/puls-diskinfo-helper|$PREFIX/libexec/puls-diskinfo-helper|g" \
    "$PREFIX/share/polkit-1/actions/io.github.puls.diskinfo.policy"

# Install icon if available
if [ -f "$SCRIPT_DIR/data/io.github.puls.diskinfo.svg" ]; then
    install -Dm644 "$SCRIPT_DIR/data/io.github.puls.diskinfo.svg" \
        "$PREFIX/share/icons/hicolor/scalable/apps/io.github.puls.diskinfo.svg"
    gtk-update-icon-cache -f "$PREFIX/share/icons/hicolor/" 2>/dev/null || true
fi

echo ""
echo "✓ PULS DiskInfo installed successfully!"
echo "  Binary:  $PREFIX/bin/puls-diskinfo"
echo "  Helper:  $PREFIX/libexec/puls-diskinfo-helper"
echo ""
echo "Run with: puls-diskinfo"
