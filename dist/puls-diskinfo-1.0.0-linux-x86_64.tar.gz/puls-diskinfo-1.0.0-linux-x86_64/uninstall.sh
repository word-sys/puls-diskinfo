#!/bin/bash
set -euo pipefail

PREFIX="${PREFIX:-/usr/local}"

if [ "$(id -u)" -ne 0 ]; then
    echo "Error: This script must be run as root (use sudo)."
    exit 1
fi

echo "Removing Puls DiskInfo from $PREFIX..."

rm -f "$PREFIX/bin/puls-diskinfo"
rm -f "$PREFIX/libexec/puls-diskinfo-helper"
rm -f "$PREFIX/share/applications/io.github.puls.diskinfo.desktop"
rm -f "$PREFIX/share/polkit-1/actions/io.github.puls.diskinfo.policy"
rm -f "$PREFIX/share/icons/hicolor/scalable/apps/io.github.puls.diskinfo.svg"

echo "✓ Puls DiskInfo removed."
